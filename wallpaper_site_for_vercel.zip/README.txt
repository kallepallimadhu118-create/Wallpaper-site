Wallpaper website (static demo)

GitHub upload steps:
1. Create a new GitHub repository named wallpaper-site.
2. Upload index.html to the repository root and commit the changes.
3. In Vercel choose Add New > Project, import wallpaper-site, then Deploy.

Important: the included admin password check is browser-side demo code only. It is NOT secure for a public website and uploaded images are saved only in the same browser/device. Before public use, replace it with server-side authentication and cloud image storage/database.
